function start(){
document.querySelector('button').style.display='none';
document.getElementById('name').style.display='none';
const g=document.getElementById('game');
for(let i=0;i<=6;i++){
 for(let j=i;j<=6;j++){
  let img=document.createElement('img');
  img.src=`assets/tiles/tile_${i}_${j}.png`;
  img.style.margin='4px';
  g.appendChild(img);
 }
}
}